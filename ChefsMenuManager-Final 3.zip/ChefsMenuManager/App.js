import React, { useState, useRef, useEffect } from 'react';
import { SafeAreaView, StatusBar, View, Text, StyleSheet } from 'react-native';
import Banner from './components/Banner';
import TabBar from './components/TabBar';
import ConfirmModal from './components/ConfirmModal';
import MenuScreen from './screens/MenuScreen';
import FormScreen from './screens/FormScreen';
import StatsScreen from './screens/StatsScreen';
import { colors, spacing, typography } from './styles/theme';

export default function App() {
  const [menuItems, setMenuItems] = useState([]);
  const [activeTab, setActiveTab] = useState('menu');
  const [dishToEdit, setDishToEdit] = useState(null);
  const [dishToDelete, setDishToDelete] = useState(null);
  const [banner, setBanner] = useState({ type: 'success', message: '' });
  const bannerTimer = useRef(null);

  // Clear any pending timer when the app closes
  useEffect(() => () => clearTimeout(bannerTimer.current), []);

  const showBanner = (type, message) => {
    clearTimeout(bannerTimer.current);
    setBanner({ type, message });
    bannerTimer.current = setTimeout(() => setBanner({ type, message: '' }), 2800);
  };

  // ----- Add / edit -----
  const handleSaveDish = (dishData) => {
    if (dishToEdit) {
      setMenuItems((items) =>
        items.map((item) => (item.id === dishToEdit.id ? { ...item, ...dishData } : item))
      );
      showBanner('success', `"${dishData.name}" was updated.`);
      setDishToEdit(null);
      setActiveTab('menu');
    } else {
      const newDish = { id: Date.now().toString(), ...dishData };
      setMenuItems((items) => [newDish, ...items]);
      showBanner('success', `"${dishData.name}" was added to the menu.`);
    }
  };

  const handleStartEdit = (dish) => {
    setDishToEdit(dish);
    setActiveTab('form');
  };

  const handleCancelEdit = () => {
    setDishToEdit(null);
    setActiveTab('menu');
  };

  // ----- Delete (with confirmation) -----
  const handleConfirmDelete = () => {
    setMenuItems((items) => items.filter((item) => item.id !== dishToDelete.id));
    showBanner('success', `"${dishToDelete.name}" was deleted.`);
    setDishToDelete(null);
  };

  // ----- Navigation -----
  const handleTabChange = (key) => {
    if (key !== 'form') setDishToEdit(null); // leaving the form abandons an edit
    setActiveTab(key);
  };

  const tabs = [
    { key: 'menu', label: 'Menu', icon: '📋' },
    { key: 'form', label: dishToEdit ? 'Edit Dish' : 'Add Dish', icon: dishToEdit ? '✏️' : '➕' },
    { key: 'stats', label: 'Statistics', icon: '📊' },
  ];

  const subtitles = {
    menu: 'Search, filter, edit and delete dishes',
    form: dishToEdit ? 'Update the details below' : 'Enter the details of a new dish',
    stats: 'An overview of the current menu',
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar barStyle="dark-content" backgroundColor={colors.background} />

      <View style={styles.header}>
        <Text style={styles.title}>Christoffel's Menu Manager</Text>
        <Text style={styles.subtitle}>{subtitles[activeTab]}</Text>
      </View>

      <Banner type={banner.type} message={banner.message} />

      <View style={styles.body}>
        {activeTab === 'menu' && (
          <MenuScreen items={menuItems} onEdit={handleStartEdit} onDelete={setDishToDelete} />
        )}
        {activeTab === 'form' && (
          <FormScreen
            dishToEdit={dishToEdit}
            onSubmit={handleSaveDish}
            onCancel={handleCancelEdit}
          />
        )}
        {activeTab === 'stats' && <StatsScreen items={menuItems} />}
      </View>

      <TabBar tabs={tabs} activeKey={activeTab} onChange={handleTabChange} />

      <ConfirmModal
        visible={!!dishToDelete}
        title="Delete this dish?"
        message={dishToDelete ? `"${dishToDelete.name}" will be removed from the menu.` : ''}
        onConfirm={handleConfirmDelete}
        onCancel={() => setDishToDelete(null)}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: colors.background },
  header: {
    paddingTop: spacing.lg,
    paddingHorizontal: spacing.md,
    paddingBottom: spacing.md,
  },
  title: { ...typography.title, color: colors.text },
  subtitle: { ...typography.body, color: colors.textMuted, marginTop: spacing.xs },
  body: { flex: 1 },
});
