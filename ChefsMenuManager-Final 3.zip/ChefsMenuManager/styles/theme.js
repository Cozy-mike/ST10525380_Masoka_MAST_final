// Shared design tokens: every component pulls colours, spacing and type
// from here so the whole app keeps one consistent look and feel.

export const colors = {
  background: '#FAF6F1',
  surface: '#FFFFFF',
  primary: '#B5482A',
  primaryDark: '#8E3A21',
  primarySoft: '#F6E4DD',
  text: '#2B2420',
  textMuted: '#8A7D74',
  border: '#E4DAD1',
  success: '#2E7D32',
  successBg: '#E8F5E9',
  error: '#C0392B',
  errorBg: '#FDECEA',
  overlay: 'rgba(0,0,0,0.45)',
  courseBadge: {
    Starter: '#C99A1E',
    Main: '#B5482A',
    Dessert: '#7A6BC7',
  },
};

export const spacing = { xs: 4, sm: 8, md: 16, lg: 24, xl: 32 };

export const radius = { sm: 6, md: 10, lg: 16, pill: 999 };

export const typography = {
  title: { fontSize: 22, fontWeight: '700' },
  subtitle: { fontSize: 16, fontWeight: '600' },
  label: { fontSize: 13, fontWeight: '600' },
  body: { fontSize: 15 },
  small: { fontSize: 12 },
};
