import React from 'react';
import { ScrollView, View, Text, StyleSheet } from 'react-native';
import StatCard from '../components/StatCard';
import EmptyState from '../components/EmptyState';
import { calculateMenuStats, formatPrice } from '../utils/menuHelpers';
import { colors, spacing, radius, typography } from '../styles/theme';

// Statistics tab: totals, averages and a per-course breakdown.
export default function StatsScreen({ items }) {
  const stats = calculateMenuStats(items);

  if (!stats) {
    return (
      <EmptyState
        emoji="📊"
        title="No statistics yet"
        message="Add some menu items and their statistics will appear here."
      />
    );
  }

  return (
    <ScrollView contentContainerStyle={styles.content}>
      <View style={styles.row}>
        <StatCard label="Total dishes" value={String(stats.totalItems)} />
        <StatCard label="Average price" value={formatPrice(stats.averagePrice)} />
      </View>
      <View style={styles.row}>
        <StatCard
          label="Cheapest"
          value={formatPrice(stats.cheapest.price)}
          caption={stats.cheapest.name}
        />
        <StatCard
          label="Most expensive"
          value={formatPrice(stats.mostExpensive.price)}
          caption={stats.mostExpensive.name}
        />
      </View>

      <Text style={styles.heading}>By course</Text>
      <View style={styles.table}>
        {stats.byCourse.map((row) => (
          <View key={row.course} style={styles.tableRow}>
            <View style={[styles.dot, { backgroundColor: colors.courseBadge[row.course] }]} />
            <Text style={styles.course}>{row.course}</Text>
            <Text style={styles.cell}>
              {row.count} dish{row.count === 1 ? '' : 'es'}
            </Text>
            <Text style={styles.cell}>
              {row.count > 0 ? `avg ${formatPrice(row.averagePrice)}` : '—'}
            </Text>
          </View>
        ))}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  content: { paddingHorizontal: spacing.md - spacing.xs, paddingBottom: spacing.xl },
  row: { flexDirection: 'row' },
  heading: {
    ...typography.subtitle,
    color: colors.text,
    marginTop: spacing.md,
    marginBottom: spacing.sm,
    marginLeft: spacing.xs,
  },
  table: {
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    marginHorizontal: spacing.xs,
  },
  tableRow: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  dot: { width: 10, height: 10, borderRadius: 5, marginRight: spacing.sm },
  course: { ...typography.subtitle, color: colors.text, width: 80 },
  cell: { ...typography.body, color: colors.textMuted, flex: 1 },
});
