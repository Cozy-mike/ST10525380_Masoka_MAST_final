import React, { useState } from 'react';
import { View, Text, FlatList, StyleSheet } from 'react-native';
import SearchFilterBar from '../components/SearchFilterBar';
import MenuItemCard from '../components/MenuItemCard';
import EmptyState from '../components/EmptyState';
import { filterMenuItems } from '../utils/menuHelpers';
import { colors, spacing, typography } from '../styles/theme';

// Menu tab: search, filter, and the list with Edit / Delete.
export default function MenuScreen({ items, onEdit, onDelete }) {
  const [searchText, setSearchText] = useState('');
  const [courseFilter, setCourseFilter] = useState('All');

  const visibleItems = filterMenuItems(items, searchText, courseFilter);

  const header = (
    <View>
      <SearchFilterBar
        searchText={searchText}
        onSearchChange={setSearchText}
        courseFilter={courseFilter}
        onFilterChange={setCourseFilter}
      />
      {items.length > 0 && (
        <Text style={styles.count}>
          Showing {visibleItems.length} of {items.length} item{items.length === 1 ? '' : 's'}
        </Text>
      )}
    </View>
  );

  const empty =
    items.length === 0 ? (
      <EmptyState
        emoji="🍽️"
        title="No menu items yet"
        message="Open the Add Dish tab to add the first dish to the menu."
      />
    ) : (
      <EmptyState
        emoji="🔎"
        title="No matching dishes"
        message="Try a different search word or choose another course filter."
      />
    );

  return (
    <FlatList
      data={visibleItems}
      keyExtractor={(item) => item.id}
      ListHeaderComponent={header}
      ListEmptyComponent={empty}
      renderItem={({ item }) => (
        <MenuItemCard item={item} onEdit={onEdit} onDelete={onDelete} />
      )}
      contentContainerStyle={styles.content}
      keyboardShouldPersistTaps="handled"
    />
  );
}

const styles = StyleSheet.create({
  content: { paddingBottom: spacing.lg },
  count: {
    ...typography.small,
    color: colors.textMuted,
    marginHorizontal: spacing.md,
    marginBottom: spacing.sm,
  },
});
