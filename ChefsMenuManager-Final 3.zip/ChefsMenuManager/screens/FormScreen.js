import React from 'react';
import { ScrollView, StyleSheet } from 'react-native';
import DishForm from '../components/DishForm';
import { spacing } from '../styles/theme';

// Add Dish / Edit Dish tab. The `key` makes the form reset whenever we
// switch between "add" and editing a different dish.
export default function FormScreen({ dishToEdit, onSubmit, onCancel }) {
  return (
    <ScrollView
      contentContainerStyle={styles.content}
      keyboardShouldPersistTaps="handled"
    >
      <DishForm
        key={dishToEdit ? dishToEdit.id : 'new'}
        dishToEdit={dishToEdit}
        onSubmit={onSubmit}
        onCancel={onCancel}
      />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  content: { paddingBottom: spacing.xl },
});
