import React from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet } from 'react-native';
import { COURSES } from '../utils/menuHelpers';
import { colors, spacing, radius, typography } from '../styles/theme';

const FILTERS = ['All', ...COURSES];

// Search box + course filter chips.
export default function SearchFilterBar({ searchText, onSearchChange, courseFilter, onFilterChange }) {
  return (
    <View style={styles.wrapper}>
      <TextInput
        style={styles.search}
        placeholder="🔍  Search by name or description"
        placeholderTextColor={colors.textMuted}
        value={searchText}
        onChangeText={onSearchChange}
        clearButtonMode="while-editing"
      />
      <View style={styles.chipRow}>
        {FILTERS.map((filter) => {
          const active = filter === courseFilter;
          return (
            <TouchableOpacity
              key={filter}
              style={[styles.chip, active && styles.chipActive]}
              onPress={() => onFilterChange(filter)}
              activeOpacity={0.8}
            >
              <Text style={[styles.chipText, active && styles.chipTextActive]}>{filter}</Text>
            </TouchableOpacity>
          );
        })}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: { paddingHorizontal: spacing.md, marginBottom: spacing.md },
  search: {
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.md,
    padding: spacing.sm + 4,
    fontSize: 15,
    color: colors.text,
  },
  chipRow: { flexDirection: 'row', marginTop: spacing.sm },
  chip: {
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.surface,
    borderRadius: radius.pill,
    paddingVertical: 6,
    paddingHorizontal: spacing.md,
    marginRight: spacing.sm,
  },
  chipActive: { backgroundColor: colors.primary, borderColor: colors.primary },
  chipText: { ...typography.label, color: colors.text },
  chipTextActive: { color: '#FFFFFF' },
});
