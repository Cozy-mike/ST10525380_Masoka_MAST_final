import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { colors, spacing, radius, typography } from '../styles/theme';

// Success / error message strip shown at the top of every screen.
export default function Banner({ type, message }) {
  if (!message) return null;
  const isSuccess = type === 'success';

  return (
    <View
      style={[
        styles.banner,
        {
          backgroundColor: isSuccess ? colors.successBg : colors.errorBg,
          borderColor: isSuccess ? colors.success : colors.error,
        },
      ]}
    >
      <Text style={[styles.text, { color: isSuccess ? colors.success : colors.error }]}>
        {isSuccess ? '✅ ' : '⚠️ '}
        {message}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  banner: {
    borderWidth: 1,
    borderRadius: radius.md,
    marginHorizontal: spacing.md,
    marginBottom: spacing.sm,
    padding: spacing.sm + 2,
  },
  text: { ...typography.body, fontWeight: '600' },
});
