import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { colors, spacing, radius, typography } from '../styles/theme';

// Small tile showing one headline number.
export default function StatCard({ label, value, caption }) {
  return (
    <View style={styles.card}>
      <Text style={styles.label}>{label}</Text>
      <Text style={styles.value}>{value}</Text>
      {!!caption && <Text style={styles.caption}>{caption}</Text>}
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    flex: 1,
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    padding: spacing.md,
    margin: spacing.xs,
  },
  label: { ...typography.small, color: colors.textMuted, fontWeight: '600' },
  value: { fontSize: 20, fontWeight: '700', color: colors.primaryDark, marginTop: spacing.xs },
  caption: { ...typography.small, color: colors.textMuted, marginTop: 2 },
});
