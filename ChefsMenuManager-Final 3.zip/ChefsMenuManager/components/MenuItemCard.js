import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import Button from './Button';
import { formatPrice } from '../utils/menuHelpers';
import { colors, spacing, radius, typography } from '../styles/theme';

// One dish in the list, with Edit and Delete actions.
export default function MenuItemCard({ item, onEdit, onDelete }) {
  return (
    <View style={styles.card}>
      <View style={styles.headerRow}>
        <Text style={styles.name}>{item.name}</Text>
        <Text style={styles.price}>{formatPrice(item.price)}</Text>
      </View>
      <Text style={styles.description}>{item.description}</Text>

      <View style={styles.footerRow}>
        <View style={[styles.badge, { backgroundColor: colors.courseBadge[item.course] }]}>
          <Text style={styles.badgeText}>{item.course}</Text>
        </View>
        <View style={styles.actions}>
          <Button title="Edit" variant="secondary" small onPress={() => onEdit(item)} />
          <View style={styles.gap} />
          <Button title="Delete" variant="danger" small onPress={() => onDelete(item)} />
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    padding: spacing.md,
    marginHorizontal: spacing.md,
    marginBottom: spacing.sm,
  },
  headerRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  name: { ...typography.subtitle, color: colors.text, flexShrink: 1, marginRight: spacing.sm },
  price: { ...typography.subtitle, color: colors.primaryDark },
  description: { ...typography.body, color: colors.textMuted, marginTop: spacing.xs },
  footerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: spacing.md,
  },
  badge: { borderRadius: radius.sm, paddingHorizontal: spacing.sm, paddingVertical: 3 },
  badgeText: { color: '#FFFFFF', fontSize: 12, fontWeight: '700' },
  actions: { flexDirection: 'row' },
  gap: { width: spacing.sm },
});
