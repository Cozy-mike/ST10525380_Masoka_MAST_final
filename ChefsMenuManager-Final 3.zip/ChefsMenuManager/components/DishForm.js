import React, { useState } from 'react';
import { View, Text, TextInput, StyleSheet } from 'react-native';
import { Picker } from '@react-native-picker/picker';
import Field from './Field';
import Button from './Button';
import { COURSES } from '../utils/menuHelpers';
import { validateDish } from '../utils/validation';
import { colors, spacing, radius, typography } from '../styles/theme';

const EMPTY_FORM = { name: '', description: '', course: '', price: '' };

// Used for BOTH adding and editing. When `dishToEdit` is supplied the
// form starts filled in and the button says "Save Changes".
export default function DishForm({ dishToEdit, onSubmit, onCancel }) {
  const isEditing = !!dishToEdit;

  const [values, setValues] = useState(
    isEditing
      ? {
          name: dishToEdit.name,
          description: dishToEdit.description,
          course: dishToEdit.course,
          price: String(dishToEdit.price),
        }
      : EMPTY_FORM
  );
  const [errors, setErrors] = useState({});

  const updateValue = (field, text) => {
    setValues((prev) => ({ ...prev, [field]: text }));
    // Clear that field's error as soon as the user starts fixing it
    if (errors[field]) setErrors((prev) => ({ ...prev, [field]: undefined }));
  };

  const handleSubmit = () => {
    const foundErrors = validateDish(values);
    setErrors(foundErrors);
    if (Object.keys(foundErrors).length > 0) return;

    onSubmit({
      name: values.name.trim(),
      description: values.description.trim(),
      course: values.course,
      price: Number(values.price),
    });

    if (!isEditing) setValues(EMPTY_FORM);
  };

  return (
    <View style={styles.card}>
      <Text style={styles.heading}>{isEditing ? 'Edit Menu Item' : 'Add a Menu Item'}</Text>

      <Field label="Dish Name" error={errors.name}>
        <TextInput
          style={[styles.input, errors.name && styles.inputError]}
          placeholder="e.g. Bobotie"
          placeholderTextColor={colors.textMuted}
          value={values.name}
          onChangeText={(text) => updateValue('name', text)}
        />
      </Field>

      <Field label="Description" error={errors.description}>
        <TextInput
          style={[styles.input, styles.multiline, errors.description && styles.inputError]}
          placeholder="Short description of the dish"
          placeholderTextColor={colors.textMuted}
          value={values.description}
          onChangeText={(text) => updateValue('description', text)}
          multiline
          numberOfLines={3}
        />
      </Field>

      <Field label="Course" error={errors.course}>
        <View style={[styles.pickerWrapper, errors.course && styles.inputError]}>
          <Picker
            selectedValue={values.course}
            onValueChange={(value) => updateValue('course', value)}
            style={styles.picker}
          >
            <Picker.Item label="Select a course..." value="" />
            {COURSES.map((course) => (
              <Picker.Item key={course} label={course} value={course} />
            ))}
          </Picker>
        </View>
      </Field>

      <Field label="Price (R)" error={errors.price}>
        <TextInput
          style={[styles.input, errors.price && styles.inputError]}
          placeholder="e.g. 89.90"
          placeholderTextColor={colors.textMuted}
          value={values.price}
          onChangeText={(text) => updateValue('price', text)}
          keyboardType="numeric"
        />
      </Field>

      <Button title={isEditing ? 'Save Changes' : 'Add Dish'} onPress={handleSubmit} />
      {isEditing && (
        <View style={styles.cancelWrapper}>
          <Button title="Cancel" variant="secondary" onPress={onCancel} />
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    padding: spacing.md,
    marginHorizontal: spacing.md,
    borderWidth: 1,
    borderColor: colors.border,
  },
  heading: { ...typography.subtitle, color: colors.text, marginBottom: spacing.md },
  input: {
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.sm,
    padding: spacing.sm + 2,
    fontSize: 15,
    color: colors.text,
    backgroundColor: colors.background,
  },
  multiline: { minHeight: 70, textAlignVertical: 'top' },
  pickerWrapper: {
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.sm,
    backgroundColor: colors.background,
    overflow: 'hidden',
  },
  picker: { color: colors.text },
  inputError: { borderColor: colors.error },
  cancelWrapper: { marginTop: spacing.sm },
});
