import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { colors, spacing, radius, typography } from '../styles/theme';

// Friendly message used whenever a list or screen has nothing to show.
export default function EmptyState({ emoji, title, message }) {
  return (
    <View style={styles.box}>
      <Text style={styles.emoji}>{emoji}</Text>
      <Text style={styles.title}>{title}</Text>
      <Text style={styles.message}>{message}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  box: {
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.border,
    borderStyle: 'dashed',
    paddingVertical: spacing.xl,
    paddingHorizontal: spacing.md,
    alignItems: 'center',
    marginHorizontal: spacing.md,
  },
  emoji: { fontSize: 32, marginBottom: spacing.sm },
  title: { ...typography.subtitle, color: colors.text, marginBottom: spacing.xs },
  message: { ...typography.body, color: colors.textMuted, textAlign: 'center' },
});
