import React from 'react';
import { Modal, View, Text, StyleSheet } from 'react-native';
import Button from './Button';
import { colors, spacing, radius, typography } from '../styles/theme';

// Custom confirm dialog (works on phone and web, unlike Alert buttons).
export default function ConfirmModal({ visible, title, message, onConfirm, onCancel }) {
  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onCancel}>
      <View style={styles.overlay}>
        <View style={styles.dialog}>
          <Text style={styles.title}>{title}</Text>
          <Text style={styles.message}>{message}</Text>
          <View style={styles.row}>
            <View style={styles.half}>
              <Button title="Cancel" variant="secondary" onPress={onCancel} />
            </View>
            <View style={styles.half}>
              <Button title="Delete" variant="danger" onPress={onConfirm} />
            </View>
          </View>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: colors.overlay,
    justifyContent: 'center',
    padding: spacing.lg,
  },
  dialog: {
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    padding: spacing.lg,
  },
  title: { ...typography.title, color: colors.text, marginBottom: spacing.sm },
  message: { ...typography.body, color: colors.textMuted, marginBottom: spacing.lg },
  row: { flexDirection: 'row' },
  half: { flex: 1, marginHorizontal: spacing.xs },
});
