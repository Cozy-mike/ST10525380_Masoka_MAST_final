import React from 'react';
import { TouchableOpacity, Text, StyleSheet } from 'react-native';
import { colors, spacing, radius } from '../styles/theme';

// One reusable button used everywhere. `variant` picks the look.
export default function Button({ title, onPress, variant = 'primary', small = false }) {
  const variantStyle = variantStyles[variant];
  return (
    <TouchableOpacity
      style={[styles.base, small && styles.small, variantStyle.container]}
      onPress={onPress}
      activeOpacity={0.85}
    >
      <Text style={[styles.text, small && styles.smallText, variantStyle.text]}>
        {title}
      </Text>
    </TouchableOpacity>
  );
}

const variantStyles = {
  primary: {
    container: { backgroundColor: colors.primary },
    text: { color: '#FFFFFF' },
  },
  secondary: {
    container: {
      backgroundColor: colors.surface,
      borderWidth: 1,
      borderColor: colors.border,
    },
    text: { color: colors.text },
  },
  danger: {
    container: { backgroundColor: colors.errorBg, borderWidth: 1, borderColor: colors.error },
    text: { color: colors.error },
  },
};

const styles = StyleSheet.create({
  base: {
    borderRadius: radius.md,
    paddingVertical: spacing.sm + 4,
    paddingHorizontal: spacing.md,
    alignItems: 'center',
    justifyContent: 'center',
  },
  small: { paddingVertical: spacing.sm, paddingHorizontal: spacing.md },
  text: { fontSize: 16, fontWeight: '700' },
  smallText: { fontSize: 14 },
});
