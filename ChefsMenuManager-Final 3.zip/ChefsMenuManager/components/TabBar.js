import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { colors, spacing, typography } from '../styles/theme';

// Bottom navigation: one tab per feature area.
export default function TabBar({ tabs, activeKey, onChange }) {
  return (
    <View style={styles.bar}>
      {tabs.map((tab) => {
        const active = tab.key === activeKey;
        return (
          <TouchableOpacity
            key={tab.key}
            style={styles.tab}
            onPress={() => onChange(tab.key)}
            activeOpacity={0.7}
          >
            <Text style={styles.icon}>{tab.icon}</Text>
            <Text style={[styles.label, active && styles.labelActive]}>{tab.label}</Text>
            {active && <View style={styles.indicator} />}
          </TouchableOpacity>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  bar: {
    flexDirection: 'row',
    backgroundColor: colors.surface,
    borderTopWidth: 1,
    borderTopColor: colors.border,
  },
  tab: { flex: 1, alignItems: 'center', paddingVertical: spacing.sm + 2 },
  icon: { fontSize: 20 },
  label: { ...typography.small, color: colors.textMuted, marginTop: 2 },
  labelActive: { color: colors.primary, fontWeight: '700' },
  indicator: {
    position: 'absolute',
    top: 0,
    height: 3,
    width: 36,
    borderRadius: 2,
    backgroundColor: colors.primary,
  },
});
