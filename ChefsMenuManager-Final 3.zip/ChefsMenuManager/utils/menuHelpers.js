// Pure helper functions (no UI) so the logic is reusable and easy to test.

export const COURSES = ['Starter', 'Main', 'Dessert'];

export const formatPrice = (value) => `R${Number(value).toFixed(2)}`;

// Returns a new list filtered by search text (name or description)
// and, optionally, by course. "All" means no course filter.
export const filterMenuItems = (items, searchText, courseFilter) => {
  const query = searchText.trim().toLowerCase();

  return items.filter((item) => {
    const matchesCourse = courseFilter === 'All' || item.course === courseFilter;
    const matchesText =
      query === '' ||
      item.name.toLowerCase().includes(query) ||
      item.description.toLowerCase().includes(query);
    return matchesCourse && matchesText;
  });
};

const average = (numbers) =>
  numbers.length === 0
    ? 0
    : numbers.reduce((sum, n) => sum + n, 0) / numbers.length;

// Builds every figure shown on the Statistics screen.
export const calculateMenuStats = (items) => {
  if (items.length === 0) return null;

  const sortedByPrice = [...items].sort((a, b) => a.price - b.price);

  const byCourse = COURSES.map((course) => {
    const courseItems = items.filter((item) => item.course === course);
    return {
      course,
      count: courseItems.length,
      averagePrice: average(courseItems.map((item) => item.price)),
    };
  });

  return {
    totalItems: items.length,
    averagePrice: average(items.map((item) => item.price)),
    cheapest: sortedByPrice[0],
    mostExpensive: sortedByPrice[sortedByPrice.length - 1],
    byCourse,
  };
};
