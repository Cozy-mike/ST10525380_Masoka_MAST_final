import { COURSES } from './menuHelpers';

// Checks the dish form values and returns an object of error messages.
// An empty object means everything is valid.
export const validateDish = ({ name, description, course, price }) => {
  const errors = {};

  if (!name.trim()) {
    errors.name = 'Dish name is required.';
  } else if (name.trim().length < 2) {
    errors.name = 'Dish name must be at least 2 characters.';
  }

  if (!description.trim()) {
    errors.description = 'Description is required.';
  }

  if (!COURSES.includes(course)) {
    errors.course = 'Please select a course.';
  }

  if (!price.trim()) {
    errors.price = 'Price is required.';
  } else if (isNaN(Number(price)) || Number(price) <= 0) {
    errors.price = 'Enter a valid price greater than 0.';
  }

  return errors;
};
