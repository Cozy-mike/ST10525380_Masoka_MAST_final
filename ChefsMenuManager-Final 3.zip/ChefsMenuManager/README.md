# Chef's Menu Manager — MAST5112 POE (Final)

React Native (Expo) app for Christoffel's chef to manage the restaurant menu.

## Run it
```
npm install
npx expo start
```
Scan the QR code with Expo Go (same Wi-Fi). Web preview needs:
`npx expo install react-native-web react-dom @expo/metro-runtime`

## Features (Final PoE)
- **Add** menu items (name, description, course, price) with validation
- **Edit** any item (form pre-fills, "Save Changes")
- **Delete** with a confirmation dialog
- **Search** by name/description and **filter** by course
- **Statistics**: total, average price, cheapest, most expensive, per-course count and average
- **Navigation**: bottom tabs (Menu / Add Dish / Statistics)
- Success + error messages, empty states, consistent theme

## Structure
```
App.js                    state + handlers (add, edit, delete) + navigation
screens/                  MenuScreen, FormScreen, StatsScreen
components/               Button, Field, Banner, EmptyState, TabBar, ConfirmModal,
                          DishForm, MenuItemCard, SearchFilterBar, StatCard
utils/menuHelpers.js      filterMenuItems, calculateMenuStats, formatPrice
utils/validation.js       validateDish
styles/theme.js           colours, spacing, typography
```

## Improvements over Part 2 (mention these in your video)
- Split one big screen into 3 screens with tab navigation
- Reusable components (Button, Field, EmptyState, DishForm for add AND edit)
- Reusable functions moved out of the UI (filtering, statistics, validation)
- Prices stored as numbers so statistics are accurate
- Errors clear as the user types; success banner auto-hides

## Demo video script (5–8 min)
1. Show empty Menu tab (empty state) and Statistics (empty state)
2. Add Dish: submit empty form to show validation, then add 4–5 dishes
3. Menu tab: show the list and the success message
4. Search for a word, then use the course filters; show "no matching dishes"
5. Edit a dish and save; show the update
6. Delete a dish via the confirmation dialog
7. Statistics tab: explain each figure
8. Quick code walkthrough: App.js, screens, components, utils

## Before submitting
- [ ] App runs with `npx expo start`
- [ ] Push to GitHub (latest code)
- [ ] Upload video to YouTube as **Unlisted** and add the link
